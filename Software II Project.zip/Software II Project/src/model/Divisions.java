package model;

import java.sql.Timestamp;

public class Divisions {
    private int divisionId;
    private String divisionName;
    private Timestamp divisionCreated;
    private String divisionCreatedBy;
    private Timestamp divisionLastUpdate;
    private String divisionLastUpdatedBy;
    private int countryId;

    public Divisions(int divisionId, String divisionName, Timestamp divisionCreated, String divisionCreatedBy,
                     Timestamp divisionLastUpdate, String divisionLastUpdatedBy, int countryId) {
        this.divisionId = divisionId;
        this.divisionName = divisionName;
        this.divisionCreated = divisionCreated;
        this.divisionCreatedBy = divisionCreatedBy;
        this.divisionLastUpdate = divisionLastUpdate;
        this.divisionLastUpdatedBy = divisionLastUpdatedBy;
        this.countryId = countryId;
    }

    public int getDivisionId() {
        return divisionId;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public Timestamp getDivisionCreated() {
        return divisionCreated;
    }

    public String getDivisionCreatedBy() {
        return divisionCreatedBy;
    }

    public Timestamp getDivisionLastUpdate() {
        return divisionLastUpdate;
    }

    public String getDivisionLastUpdatedBy() {
        return divisionLastUpdatedBy;
    }

    public int getCountryId() {
        return countryId;
    }

    @Override
    public String toString(){
        return divisionName;
    }
}
