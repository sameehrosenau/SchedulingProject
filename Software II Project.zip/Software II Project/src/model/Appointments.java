package model;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;


public class Appointments {
    private int appointmentId;
    private String appointmentTitle;
    private String appointmentDescription;
    private String appointmentLocation;
    private String appointmentType;
    private LocalDate appointmentStartDate;
    private LocalTime appointmentStartTime;
    private LocalDate appointmentEndDate;
    private LocalTime appointmentEndTime;
    private Timestamp appointmentCreated;
    private String appointmentCreatedBy;
    private Timestamp appointmentLastUpdate;
    private String appointmentLastUpdatedBy;
    private int customerId;
    private int userId;
    private int contactId;

    private static int apptCount = 0;
    
    public Appointments(int appointmentId, String appointmentTitle, String appointmentDescription,
                        String appointmentLocation, String appointmentType, LocalDate appointmentStartDate,
                        LocalTime appointmentStartTime, LocalDate appointmentEndDate, LocalTime appointmentEndTime,
                        int customerId, int userId, int contactId)
    {
        this.appointmentId = appointmentId;
        this.appointmentTitle = appointmentTitle;
        this.appointmentDescription = appointmentDescription;
        this.appointmentLocation = appointmentLocation;
        this.appointmentType = appointmentType;
        this.appointmentStartDate = appointmentStartDate;
        this.appointmentStartTime = appointmentStartTime;
        this.appointmentEndDate = appointmentEndDate;
        this.appointmentEndTime = appointmentEndTime;
        this.customerId = customerId;
        this.userId = userId;
        this.contactId = contactId;
    }

    public int getAppointmentId() {
        return appointmentId;
    }

    public String getAppointmentTitle() {
        return appointmentTitle;
    }

    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    public String getAppointmentLocation() {
        return appointmentLocation;
    }

    public String getAppointmentType() {
        return appointmentType;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getUserId() {
        return userId;
    }

    public int getContactId() {
        return contactId;
    }

    public LocalDate getAppointmentStartDate() {
        return appointmentStartDate;
    }

    public LocalTime getAppointmentStartTime() {
        return appointmentStartTime;
    }

    public LocalDate getAppointmentEndDate() {
        return appointmentEndDate;
    }

    public LocalTime getAppointmentEndTime() {
        return appointmentEndTime;
    }

    @Override
    public String toString(){
        return appointmentType;
    }

}