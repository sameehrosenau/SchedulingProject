package model;

import java.sql.Timestamp;

public class Users {
    private int userId;
    private String userName;
    private String password;
    private Timestamp userCreated;
    private String userCreatedBy;
    private Timestamp userLastUpdated;
    private String userLastUpdatedBy;

    public Users(int userId, String userName, String password, Timestamp userCreated, String userCreatedBy,
                 Timestamp userLastUpdated, String userLastUpdatedBy) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
        this.userCreated = userCreated;
        this.userCreatedBy = userCreatedBy;
        this.userLastUpdated = userLastUpdated;
        this.userLastUpdatedBy = userLastUpdatedBy;
    }

    public int getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public Timestamp getUserCreated() {
        return userCreated;
    }

    public String getUserCreatedBy() {
        return userCreatedBy;
    }

    public Timestamp getUserLastUpdated() {
        return userLastUpdated;
    }

    public String getUserLastUpdatedBy() {
        return userLastUpdatedBy;
    }

    @Override
    public String toString(){
        return userName;
    }
}
