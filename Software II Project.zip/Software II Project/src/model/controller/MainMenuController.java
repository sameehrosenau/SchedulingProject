package model.controller;

import dbAccess.DBCustomers;
import model.Customers;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * The Main Menu Controller gives users access to all of the functions of the application.
 */

public class MainMenuController implements Initializable{
    Stage stage;
    Parent scene;

    @FXML
    private TableView<Customers> mainCustomerTableView;
    @FXML
    private TableColumn<Customers, String> mainCustIdCol;
    @FXML
    private TableColumn<Customers, String> mainCustNameCol;
    @FXML
    private TableColumn<Customers, String> mainCustAddressCol;
    @FXML
    private TableColumn<Customers, String> mainCustPhoneCol;
    @FXML
    private TableColumn<Customers, String> mainCustPostCol;
    @FXML
    private TableColumn<Customers, String> mainCustStateProvCol;
    @FXML
    private TableColumn<Customers, String> mainCustCountryCol;
    @FXML
    private TableColumn<Customers, Integer> mainCustDivisionIdCol;
    @FXML
    private TextField mainCustomerSearchTxt;

    /**
     * The initialize function for the Main Menu Controller populates the Customers table view.
     * @param url
     * @param rb
     */
    public void initialize(URL url, ResourceBundle rb) {
        mainCustomerTableView.setItems(DBCustomers.getAllCustomers());

        mainCustIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        mainCustNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        mainCustAddressCol.setCellValueFactory(new PropertyValueFactory<>("customerAddress"));
        mainCustPhoneCol.setCellValueFactory(new PropertyValueFactory<>("customerPhone"));
        mainCustStateProvCol.setCellValueFactory(new PropertyValueFactory<>("divisionName"));
        mainCustCountryCol.setCellValueFactory(new PropertyValueFactory<>("countryName"));
        mainCustDivisionIdCol.setCellValueFactory(new PropertyValueFactory<>("customerDivisionId"));
        mainCustPostCol.setCellValueFactory(new PropertyValueFactory<>("customerPostCode"));

    }

    /**
     * The Open New Customer Menu Button Event Handler takes the user to the New Customer window.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionOpenNewCustomerMenu(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/NewCustomer.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * The Open Edit Customer Menu Button Event Handler takes the user to the Edit Customer window.
     * That window will be populated with the selected customer's record for editing.
     * @param event - customer clicks the button
     * @throws IOException
     */
    @FXML
    private void onActionOpenEditCustomerMenu(ActionEvent event) throws IOException {
        Customers customer = mainCustomerTableView.getSelectionModel().getSelectedItem();
        if(customer == null){
            return;
        }

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/model/view/EditCustomer.fxml"));
        loader.load();

        EditCustomerController ADMController = loader.getController();
        ADMController.retrieveCustomer(customer);

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * The Confirm Delete Customer Button Event Handler throws a popup to confirm the user's intention to delete a customer record.
     * If the user confirms, the customer record is deleted, assuming there are no pending appointments with that customer.
     * If there are associated appointments, the user will not be allowed to delete the customer record.
     * If the user declines, the customer record is preserved, the popup closes, and the user is returned to Main Menu.
     *
     * @param event - customer clicks the button
     * @throws IOException
     */
    @FXML
    private void onActionConfirmDeleteCustomer(ActionEvent event) throws IOException {
        Customers customer = mainCustomerTableView.getSelectionModel().getSelectedItem();

        if(customer == null){
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you wish to delete?");
        Optional<ButtonType> result = alert.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
            DBCustomers.deleteCustomer(customer);
            mainCustomerTableView.setItems(DBCustomers.getAllCustomers());
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Customer Deleted");
            alert.setContentText("The customer record was successfully deleted.");
            alert.showAndWait();
        }
    }

    /**
     * The Open Scheduling Menu Button Event Handler brings the user to the Scheduling Menu
     * @param event - customer clicks the button
     * @throws IOException
     */
    @FXML
    private void onActionOpenSchedulingMenu(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/SchedulingMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * The Open Reports Menu Button Event Handler brings the user to the Reports Menu
     * @param event - customer clicks the button
     * @throws IOException
     */
    @FXML
    private void onActionOpenReportsMenu(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/ReportsMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * The Sign Out Button Event Handler closes the Main Menu and returns the user to the Login Screen
     * @param event - customer clicks the button
     * @throws IOException
     */
    @FXML
    private void onActionSignOut(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/LogInScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

}
