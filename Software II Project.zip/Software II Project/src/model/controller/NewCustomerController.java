package model.controller;

import dbAccess.DBCountries;
import dbAccess.DBDivisions;
import dbAccess.DBCustomers;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Countries;
import model.Customers;
import model.Divisions;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class NewCustomerController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private TextField newCustIdTxt;

    @FXML
    private TextField newCustNameTxt;

    @FXML
    private TextField newCustAddressTxt;

    @FXML
    private ComboBox<Countries> newCustCountryComboBx;

    @FXML
    private TextField newCustPostCodeTxt;

    @FXML
    private ComboBox<Divisions> newCustStateProvComboBx;

    @FXML
    private TextField newCustPhoneTxt;

    final static String NO_ID = "?";

    /**
     * the Initialize method in the new customer controller sets the values for the combo boxes in the view.
     * @param url
     * @param rb
     */

    public void initialize(URL url, ResourceBundle rb) {

        newCustCountryComboBx.setItems(DBCountries.getAllCountries());
        newCustStateProvComboBx.setItems(DBDivisions.getAllDivisions());

    }

    /**
     * the Save handler "Grabs" the values entered into the fields and, assuming all values are valid, saves the new
     * customer entry to the database. The user is then returned to the main menu.
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionSaveCustReturnMain(ActionEvent event) throws IOException {
        String customerName = newCustNameTxt.getText();
        String customerAddress = newCustAddressTxt.getText();
        String customerPostCode = newCustPostCodeTxt.getText();
        String customerPhone = newCustPhoneTxt.getText();
        Divisions D = newCustStateProvComboBx.getValue();
        Countries C = newCustCountryComboBx.getValue();

        if(D == null || C == null || customerName == "" || customerAddress == "" || customerPostCode == "" ||
                customerPhone == ""){
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Please provide valid entries for each field.");
            Optional<ButtonType> result = alert.showAndWait();
            return;
        }

        else {
            DBCustomers.createCustomer(customerName, customerAddress, customerPostCode, customerPhone,
                    D.getDivisionId());
        }

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * the Cancel button handler returns the user to the main menu without saving the customer entry.
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionReturnToMain(ActionEvent event) throws IOException {

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * the set division handler sets the values in the division combo box based on which country is selected.
     * @param event
     */
    public void onActionSetDivision(ActionEvent event) {
        Countries c = newCustCountryComboBx.getValue();
        newCustStateProvComboBx.setItems(DBDivisions.getAllDivisionsByCountry(c.getCountryId()));
    }
}
