package model.controller;

import database.DBConnection;
import dbAccess.DBAppointments;
import dbAccess.DBContacts;
import dbAccess.DBCountries;
import dbAccess.DBCustomers;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments;
import model.Contacts;
import model.Countries;
import model.Customers;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * The Reports Menu Controller gives users access to all of the three different reports generated in this application.
 */

public class ReportsMenuController implements Initializable{
    Stage stage;
    Parent scene;

    @FXML
    private ComboBox reportsMonthComboBx;

    @FXML
    private ComboBox reportsTypeComboBx;

    @FXML
    private TextField reportsApptTotalDisplayTxt;

    @FXML
    private ComboBox reportsSchedContactComboBx;

    @FXML
    private TableView<Appointments> reportsApptTableView;

    @FXML
    private TableColumn<Appointments, Double> reportsApptIdCol;

    @FXML
    private TableColumn<Appointments, String> reportsTitleCol;

    @FXML
    private TableColumn<Appointments, String> reportsDescriptionCol;

    @FXML
    private TableColumn<Appointments, String> reportsTypeCol;

    @FXML
    private TableColumn<Appointments, String> reportsStartDateCol;

    @FXML
    private TableColumn<Appointments, String> reportsStartTimeCol;

    @FXML
    private TableColumn<Appointments, String> reportsEndDateCol;

    @FXML
    private TableColumn<Appointments, String> reportsEndTimeCol;

    @FXML
    private TableColumn<Appointments, Integer> reportsCustomerIdCol;

    @FXML
    private ComboBox reportsCustomersbyCountryComboBx;

    @FXML
    private TextField reportsCustomersByCountryDisplayTxt;

    /**
     * the Initialize function in the Reports Menu controller sets the values for the combo boxes,
     * populates the appointment table with all appointments, and sets prompt text for the combo boxes.
     * @param url
     * @param rb
     */

    public void initialize(URL url, ResourceBundle rb) {
        ObservableList<String> monthsList = DBAppointments.getMonths();
        reportsMonthComboBx.setItems(monthsList);
        reportsMonthComboBx.setPromptText("Month");
        ObservableList<String> typesList = DBAppointments.getAllTypes();
        reportsTypeComboBx.setItems(typesList);
        reportsTypeComboBx.setPromptText("Type");

        reportsApptTableView.setItems(DBAppointments.getAllAppointments());

        reportsApptIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        reportsTitleCol.setCellValueFactory(new PropertyValueFactory<>("appointmentTitle"));
        reportsDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("appointmentDescription"));
        reportsTypeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        reportsStartDateCol.setCellValueFactory(new PropertyValueFactory<>("appointmentStartDate"));
        reportsStartTimeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentStartTime"));
        reportsEndDateCol.setCellValueFactory(new PropertyValueFactory<>("appointmentEndDate"));
        reportsEndTimeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentEndTime"));
        reportsCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));

        ObservableList<Contacts> contacts = DBContacts.getAllContacts();
        reportsSchedContactComboBx.setItems(contacts);
        reportsSchedContactComboBx.setPromptText("Contact");

        ObservableList<Countries> countries = DBCountries.getAllCountries();
        reportsCustomersbyCountryComboBx.setItems(countries);
        reportsCustomersbyCountryComboBx.setPromptText("Country");

    }

    /**
     * the event handler for the contact schedule table view changes the appointments displayed when a contact is selected
     * from the contacts combo box. the appointments displayed are those associated with the selected contact.
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionSetContactSchedTblView(ActionEvent event) throws IOException {
        ObservableList<Appointments> matchingAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        Contacts selectedContact = (Contacts) reportsSchedContactComboBx.getValue();

        for(Appointments ap : allAppointments){
            if(selectedContact.getContactId() == ap.getContactId()){
                matchingAppointments.add(ap);
            }
        }

        reportsApptTableView.setItems(matchingAppointments);
    }

    /**
     * the Number of Customers by Country event handler sets the text field to display the number of customers based
     * on which country is selected in the country combo box.
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionSetCustByCountryTxt(ActionEvent event) throws IOException{
        ObservableList<Customers> matchingCustomersByCountry = FXCollections.observableArrayList();

        ObservableList<Customers> allCustomers = DBCustomers.getAllCustomers();

        Countries selectedCountry = (Countries) reportsCustomersbyCountryComboBx.getValue();

        for(Customers cu : allCustomers){
            if(selectedCountry.getCountryId() == cu.getCountryId()){
                matchingCustomersByCountry.add(cu);
            }
        }

        int total = matchingCustomersByCountry.size();

        reportsCustomersByCountryDisplayTxt.setText(String.valueOf(total));
    }

    /**
     * for the set month/type total event handler, the user selects one month and one appointment type from the combo
     * boxes. the function returns a count of how many appointments of the selected type are on the calendar for the
     * selected month.
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionSetMonthTypeTotal(ActionEvent event) throws IOException{

        try {
            String result = null;
            String sqlApptsByMonthAndType = "SELECT count(*) from appointments where MONTHNAME(Start) = ? and Type = ?";

            PreparedStatement pstAMT = DBConnection.getConnection().prepareStatement(sqlApptsByMonthAndType);

            pstAMT.setString(1, (String) reportsMonthComboBx.getValue());
            pstAMT.setString(2, (String) reportsTypeComboBx.getValue());

            ResultSet rs = pstAMT.executeQuery();

            rs.next();

            int count = rs.getInt(1);

            if((reportsTypeComboBx.getValue() != null && reportsMonthComboBx.getValue() != null)){
                reportsApptTotalDisplayTxt.setText(String.valueOf(count));
            }

        }

        catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * using the cancel button handler, the user is returned to the main menu.
     * @param event
     * @throws IOException
     */

    @FXML
    private void onActionReturntoMain(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

}