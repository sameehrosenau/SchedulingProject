package model.controller;

import dbAccess.DBCountries;
import dbAccess.DBCustomers;
import dbAccess.DBDivisions;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Contacts;
import model.Countries;
import model.Customers;
import model.Divisions;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Edit Customer Controller provides functionality for the user to edit existing customer records.
 */

public class EditCustomerController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private TextField editCustIdTxt;

    @FXML
    private TextField editCustNameTxt;

    @FXML
    private TextField editCustAddressTxt;

    @FXML
    private ComboBox <Countries> editCustCountryComboBx;

    @FXML
    private TextField editCustPostCodeTxt;

    @FXML
    private ComboBox <Divisions> editCustStateProvComboBx;

    @FXML
    private TextField editCustPhoneTxt;

    int custModIndex;

    /**
     * the initialize method of the edit customer controller sets the combo box value options for countries and divisions.
     * @param url
     * @param rb
     */

    public void initialize(URL url, ResourceBundle rb) {

        ObservableList<Countries> countries = DBCountries.getAllCountries();
        ObservableList<Divisions> divisions = DBDivisions.getAllDivisions();
        editCustCountryComboBx.setItems(countries);
        editCustStateProvComboBx.setItems(divisions);

    }

    /**
     * the Retrieve Customer function "grabs" all of the values pertaining to the customer record selected to be
     * edited, then sets the fields in the Edit Customer view to those values.
     * @param customer
     */

    public void retrieveCustomer(Customers customer){
        editCustIdTxt.setText(String.valueOf(customer.getCustomerId()));
        editCustNameTxt.setText(String.valueOf(customer.getCustomerName()));
        editCustAddressTxt.setText(String.valueOf(customer.getCustomerAddress()));
        editCustPhoneTxt.setText(String.valueOf(customer.getCustomerPhone()));
        editCustPostCodeTxt.setText(customer.getCustomerPostCode());

        for(Countries c : editCustCountryComboBx.getItems()){
            if(c.getCountryId() == customer.getCountryId()){
                editCustCountryComboBx.setValue(c);
                break;
            }
        }

        for(Divisions d : editCustStateProvComboBx.getItems()){
            if(d.getDivisionId() == customer.getCustomerDivisionId()){
                editCustStateProvComboBx.setValue(d);
                break;
            }
        }
    }

    /**
     * The Save Customer Button Event Handler will save the customer record edits and return the user to the Main Menu.
     * The changed details should then be populated into the customer record in the Main Menu Customer Table.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionSaveCustReturnMain(ActionEvent event) throws IOException {
        String customerName = editCustNameTxt.getText();
        String customerAddress = editCustAddressTxt.getText();
        String customerPostCode = editCustPostCodeTxt.getText();
        String customerPhone = editCustPhoneTxt.getText();
        int customerId = Integer.parseInt(editCustIdTxt.getText());
        Divisions D = editCustStateProvComboBx.getValue();
        Countries C = editCustCountryComboBx.getValue();

        if(D == null || C == null || customerName.isEmpty() || customerAddress.isEmpty() || customerPostCode.isEmpty() ||
                customerPhone.isEmpty() || editCustIdTxt.getText() == ""){
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Please provide valid entries for each field.");
            Optional<ButtonType> result = alert.showAndWait();
            return;
        }

        else {
            DBCustomers.editCustomer(customerName, customerAddress, customerPostCode, customerPhone,
                    D.getDivisionId(), customerId);
        }

        onActionSetDivision(null);

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * The Cancel Button Event Handler in the Edit Customer Menu will cancel editing the customer record.
     * The user will be returned to the Main Menu.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionReturnMain(ActionEvent event) throws IOException {

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * The onActionSetDivision function sets the division combo box options based on the country selected from the
     * country combo box.
     * @param event
     */

    @FXML
    public void onActionSetDivision(ActionEvent event) {
        Countries c = editCustCountryComboBx.getValue();
        editCustStateProvComboBx.setItems(DBDivisions.getAllDivisionsByCountry(c.getCountryId()));
    }
}