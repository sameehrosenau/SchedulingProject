package model.controller;

import dbAccess.DBAppointments;
import dbAccess.DBContacts;
import dbAccess.DBCustomers;
import dbAccess.DBUsers;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.time.*;
import java.time.format.DateTimeParseException;
import java.util.ResourceBundle;

    /**
     * Edit Appointment Controller provides functionality for the user to edit existing appointments
     */

public class EditAppointmentController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private TextField editApptIdTxt;

    @FXML
    private TextField editApptTitleTxt;

    @FXML
    private TextArea editApptDescriptionTxt;

    @FXML
    private TextField editApptLocationTxt;

    @FXML
    private ComboBox <Contacts> editApptContactComboBx;

    @FXML
    private ComboBox <String> editApptTypeComboBx;

    @FXML
    private DatePicker editApptStartDatePicker;

    @FXML
    private TextField editApptStartTimeTxt;

    @FXML
    private DatePicker editApptEndDatePicker;

    @FXML
    private TextField editApptEndTimeTxt;

    @FXML
    private ComboBox <Customers> editApptCustomerIdComboBx;

    @FXML
    private ComboBox <Users> editApptUserIdComboBx;

    /**
     * The initialize method of the Edit appointment controller sets the values to populate the combo boxes.
     *
     * @param url, rb
    */

    public void initialize(URL url, ResourceBundle rb) {

        ObservableList<Contacts> contacts = DBContacts.getAllContacts();
        ObservableList<String> typesList = DBAppointments.getAllTypes();
        ObservableList<Customers> custList = DBCustomers.getAllCustomers();
        ObservableList<Users> userList = DBUsers.getAllUsers();
        editApptContactComboBx.setItems(contacts);
        editApptTypeComboBx.setItems(typesList);
        editApptCustomerIdComboBx.setItems(custList);
        editApptUserIdComboBx.setItems(userList);

    }

    /**
     * The Save Appointment Button Event Handler will save the appointment details and return the user to the Scheduling Menu.
     * The saved appointment details should then be populated into the Consultant Schedule first Table View (Appointments Table).
     * Implements error checks to ensure no null values are saved to an appointment.
     * Upon saving changes, the user is returned to the main scheduling menu view.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionSaveApptReturnSchedulingMenu(ActionEvent event) throws IOException {
        String appointmentTitle = editApptTitleTxt.getText();
        String appointmentDescription = editApptDescriptionTxt.getText();
        String appointmentLocation = editApptLocationTxt.getText();
        String appointmentType = editApptTypeComboBx.getValue();
        LocalDate appointmentStartDate = editApptStartDatePicker.getValue();
        LocalTime appointmentStartTime = LocalTime.parse(editApptStartTimeTxt.getText());
        LocalDate appointmentEndDate = editApptEndDatePicker.getValue();
        LocalTime appointmentEndTime = LocalTime.parse(editApptEndTimeTxt.getText());

        if (appointmentStartDate == null){
            return;
        }

        if (appointmentStartTime == null){
            return;
        }

        if (appointmentEndDate == null){
            return;
        }

        if (appointmentEndTime == null){
            return;
        }

        Customers C = editApptCustomerIdComboBx.getValue();
        if (C == null) {
            return;
        }

        Users U = editApptUserIdComboBx.getValue();
        if (U == null) {
            return;
        }

        Contacts X = (editApptContactComboBx.getValue());
        if (X == null) {
            return;
        }

        int appointmentId = Integer.parseInt(editApptIdTxt.getText());

        int customerId = C.getCustomerId();
        int userId = U.getUserId();
        int contactId = X.getContactId();

        if(appointmentType == null){
            return;
        }

        LocalTime estStart = LocalTime.of(8,0);
        LocalTime estEnd = LocalTime.of(22, 0);
        LocalDateTime localStart = LocalDateTime.of(appointmentStartDate, appointmentStartTime);
        ZonedDateTime localZonedStart = localStart.atZone(ZoneId.systemDefault());
        ZonedDateTime estZonedStart = localZonedStart.withZoneSameInstant(ZoneId.of("America/New_York"));
        LocalTime estStartTest = estZonedStart.toLocalTime();
        if(estStart.isAfter(estStartTest)){
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Error");
            alert1.setContentText("The appointment start time is outside of business hours.");
            alert1.showAndWait();
            return;
        }

        LocalDateTime localEnd = LocalDateTime.of(appointmentEndDate, appointmentEndTime);
        ZonedDateTime localZonedEnd = localEnd.atZone(ZoneId.systemDefault());
        ZonedDateTime estZonedEnd = localZonedEnd.withZoneSameInstant(ZoneId.of("America/New_York"));
        LocalTime estEndTest = estZonedEnd.toLocalTime();
        if(estEnd.isBefore(estEndTest)){
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Error");
            alert1.setContentText("The appointment end time is outside of business hours.");
            alert1.showAndWait();
            return;
        }


        //make sure start is before end time
        if(localStart.isAfter(localEnd)){
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Error");
            alert1.setContentText("The appointment start time must be before the appointment end time.");
            alert1.showAndWait();
            return;
        }

        ObservableList <Appointments> aList = DBAppointments.getAllAppointments();

        for(Appointments a : aList) {
            if (a.getCustomerId() != customerId) {
                continue;
            }
            if (!a.getAppointmentStartDate().equals(appointmentStartDate)) {
                continue;
            }
            if (a.getAppointmentId() == appointmentId) {
                continue;
            }

            //exS = existing StartTime
            //exE = existing EndTime
            //
            //newS = new StartTime
            //newE = new EndTime
            //appointment = to be created appt rs
            LocalTime newS = appointmentStartTime;
            LocalTime newE = appointmentEndTime;

            LocalTime exS = a.getAppointmentStartTime();
            LocalTime exE = a.getAppointmentEndTime();
            //existing red
            //new orange

            if ((newS.isBefore(exS) || newS.equals(exS)) && newE.isAfter(exS)) {
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Error");
                alert1.setContentText("Appointment ID: " + a.getAppointmentId() + " overlaps with the appointment" +
                        " the user is attempting to create.");
                alert1.showAndWait();
                return;
            }
            if ((newS.isAfter(exS) || newS.equals(exS)) && newS.isBefore(exE)) {
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Error");
                alert1.setContentText("Appointment ID: " + a.getAppointmentId() + " overlaps with the appointment" +
                        " the user is attempting to create.");
                alert1.showAndWait();
                return;
            }
            if ((newS.isAfter(exS) || newS.equals(exS)) && (newE.isBefore(exE) || newE.equals(exE))) {
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Error");
                alert1.setContentText("Appointment ID: " + a.getAppointmentId() + " overlaps with the appointment" +
                        " the user is attempting to create.");
                alert1.showAndWait();
                return;
            }

            DBAppointments.editAppointment(appointmentId, appointmentTitle, appointmentDescription,
                    appointmentLocation, appointmentType, appointmentStartDate, appointmentStartTime, appointmentEndDate,
                    appointmentEndTime, customerId, userId, contactId);
        }

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/SchedulingMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * The Cancel Button Event Handler in the Edit Appointment Menu will cancel editing the appointment.
     * The user will be returned to the Scheduling Menu.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionCancelToSchedulingMenu(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/SchedulingMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

        /**
         * the Retrieve Appointment function "grabs" all of the values pertaining to the appointment selected to be
         * edited, then sets the fields in the edit appointment view to those values.
         * @param appointment
         */
    public void retrieveAppointment(Appointments appointment) {
        editApptIdTxt.setText(String.valueOf(appointment.getAppointmentId()));
        editApptTitleTxt.setText(appointment.getAppointmentTitle());
        editApptDescriptionTxt.setText(appointment.getAppointmentDescription());
        editApptLocationTxt.setText(appointment.getAppointmentLocation());
        editApptTypeComboBx.setValue(appointment.getAppointmentType());
        editApptStartDatePicker.setValue(appointment.getAppointmentStartDate());
        editApptEndDatePicker.setValue(appointment.getAppointmentEndDate());
        editApptStartTimeTxt.setText(appointment.getAppointmentStartTime().toString());
        editApptEndTimeTxt.setText(appointment.getAppointmentEndTime().toString());

        for(Contacts x : editApptContactComboBx.getItems()){
            if(x.getContactId() == appointment.getContactId()){
                editApptContactComboBx.setValue(x);
                break;
            }
        }

        for(Users u : editApptUserIdComboBx.getItems()){
            if(u.getUserId() == appointment.getUserId()){
                editApptUserIdComboBx.setValue(u);
                break;
            }
        }

        for(Customers c : editApptCustomerIdComboBx.getItems()){
            if(c.getCustomerId() == appointment.getCustomerId()){
                editApptCustomerIdComboBx.setValue(c);
                break;
            }
        }

    }
}