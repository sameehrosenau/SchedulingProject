package model.controller;

import database.DBConnection;
import dbAccess.DBAppointments;
import dbAccess.DBCustomers;
import javafx.application.Platform;
import javafx.beans.property.Property;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments;
import model.Customers;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * the scheduling menu controller gives the user functionality to view, create, edit, and delete appointments.
 */

public class SchedulingMenuController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private RadioButton weekFilterRadioBtn;

    @FXML
    private RadioButton monthFilterRadioBtn;

    @FXML
    private RadioButton viewAllFilterRadioBtn;

    @FXML
    private TableView <Appointments> schedApptTableView;

    @FXML
    private TableColumn<Appointments, Double> schedApptIdCol;

    @FXML
    private TableColumn<Appointments, String> schedTitleCol;

    @FXML
    private TableColumn<Appointments, String> schedDescriptionCol;

    @FXML
    private TableColumn<Appointments, String> schedLocationCol;

    @FXML
    private TableColumn<Appointments, String> schedContactCol;

    @FXML
    private TableColumn<Appointments, String> schedTypeCol;

    @FXML
    private TableColumn<Appointments, String> schedStartDateCol;

    @FXML
    private TableColumn<Appointments, String> schedStartTimeCol;

    @FXML
    private TableColumn<Appointments, String> schedEndDateCol;

    @FXML
    private TableColumn<Appointments, String> schedEndTimeCol;

    @FXML
    private TableColumn<Appointments, Integer> schedCustomerIdCol;

    /**
     * the initialize method for the scheduling menu controller populates the appointment table.
     * @param url
     * @param rb
     */

    public void initialize(URL url, ResourceBundle rb) {
        schedApptTableView.setItems(DBAppointments.getAllAppointments());

        schedApptIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        schedTitleCol.setCellValueFactory(new PropertyValueFactory<>("appointmentTitle"));
        schedDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("appointmentDescription"));
        schedLocationCol.setCellValueFactory(new PropertyValueFactory<>("appointmentLocation"));
        schedTypeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        schedStartDateCol.setCellValueFactory(new PropertyValueFactory<>("appointmentStartDate"));
        schedStartTimeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentStartTime"));
        schedEndDateCol.setCellValueFactory(new PropertyValueFactory<>("appointmentEndDate"));
        schedEndTimeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentEndTime"));
        schedCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        schedContactCol.setCellValueFactory(new PropertyValueFactory<>("contactId"));

    }

    /**
     * on the Edit Appointment button handler, the user must first select an appointment or else nothing will happen.
     * once an appointment is selected and the edit appointment button is pressed, the user is brought to the
     * edit appointment view.
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionOpenEditAppointmentMenu(ActionEvent event) throws IOException {
        Appointments appointment = schedApptTableView.getSelectionModel().getSelectedItem();
        if(appointment == null){
            return;
        }

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/model/view/EditAppointment.fxml"));
        loader.load();

        EditAppointmentController ADMController = loader.getController();
        ADMController.retrieveAppointment(appointment);

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * when a user wants to delete an appointment, they must first select the appointment they wish to delete.
     * a pop-up window will come up and confirm that the user wishes to delete. If the user confirms, a second
     * pop-up confirms the deletion. If the user declines to confirm, nothing happens.
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionConfirmAppointmentDelete(ActionEvent event) throws IOException {
        Appointments appointment = schedApptTableView.getSelectionModel().getSelectedItem();

        if(appointment == null){
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you wish to delete?");
        Optional<ButtonType> result = alert.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
            DBAppointments.deleteAppointment(appointment);
            schedApptTableView.setItems(DBAppointments.getAllAppointments());
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Appointment Deleted");
            alert.setContentText("Appointment ID: " + appointment.getAppointmentId() + ", Type: " +
                            appointment.getAppointmentType() + " was deleted.");
            alert.showAndWait();
        }
    }

    /**
     * for the new appointment button handler, the user is brought to the new appointment view.
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionOpenNewAppointmentMenu(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/NewAppointment.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    private void onActionSelectFilter(ActionEvent event) throws IOException{
        if(weekFilterRadioBtn.isSelected()){
            ObservableList<Appointments> weekFilterList = DBAppointments.getWeeklyAppointments();
            schedApptTableView.setItems(weekFilterList);
        }
        else if(monthFilterRadioBtn.isSelected()){
            ObservableList<Appointments> monthFilterList = DBAppointments.getMonthlyAppointments();
            schedApptTableView.setItems(monthFilterList);
        }
        else{
            ObservableList<Appointments> viewAllFilterList = DBAppointments.getAllAppointments();
            schedApptTableView.setItems(viewAllFilterList);
        }
    }

    /**
     * for the cancel button handler, the user is brought back to the main menu.
     * @param event
     * @throws IOException
     */

    @FXML
    private void onActionCanceltoMainMenu(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

}
