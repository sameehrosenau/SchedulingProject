package model.controller;

import database.DBConnection;
import dbAccess.DBAppointments;
import dbAccess.DBUsers;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointments;
import model.Users;

import javax.swing.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Log In Screen controller sets up the opening model.view of the program.
 */

public class LogInScreenController implements Initializable {
   Stage stage;
   Parent scene;

    @FXML
    private TextField loginUserIdTxt;
    @FXML
    private TextField loginPasswordTxt;
    @FXML
    private Button loginLogInBtn;
    @FXML
    private Button cancelBtn;
    @FXML
    private Label loginLocationLabel;
    @FXML
    private Label loginUserIdLbl;
    @FXML
    private Label loginPasswordLbl;

    ResourceBundle bundle = ResourceBundle.getBundle("model/Nat");

    /**
     * @param url
     * @param rb
     * The initialize function of the login screen controller sets the login location to the
     * program user's system default
     */

    public void initialize(URL url, ResourceBundle rb) {
        loginLocationLabel.setText(ZoneId.systemDefault().toString());

        loginUserIdLbl.setText(bundle.getString("ID"));
        loginLogInBtn.setText(bundle.getString("login"));
        loginPasswordLbl.setText(bundle.getString("password"));
        cancelBtn.setText(bundle.getString("cancel"));
    }

    /**
     * The Log In Button Event Handler confirms that the login credentials are valid.
     * if valid, appointment times are checked to see whether there is an appointment within the next 15 minutes.
     * If so, the user gets a pop-up saying so and provides the appointment id.
     * If not, the user gets a pop-up saying there are no upcoming appointments.
     * The user gains access to the program and is brought to the Main Menu.
     * If the credentials are invalid, a pop-up window will alert the user of the error and they will be prompted to
     * enter their credentials again.
     */

    @FXML
    private void onActionLogin(ActionEvent event) throws IOException {
        boolean successfulLogin = false;

        String username = loginUserIdTxt.getText();
        String password = loginPasswordTxt.getText();

        Users U = DBUsers.getUser(username, password);

        if (U != null) {
            ObservableList<Appointments> allAppts = DBAppointments.getAllAppointments();
            boolean found = false;

            for(Appointments a : allAppts){
                if(a.getUserId() == U.getUserId()){
                    LocalDateTime Start = LocalDateTime.of(a.getAppointmentStartDate(), a.getAppointmentStartTime());
                    if(Start.isAfter(LocalDateTime.now()) && Start.isBefore(LocalDateTime.now().plusMinutes(15))){
                        found = true;
                        int apptId = a.getAppointmentId();
                        Alert alert = new Alert(Alert.AlertType.INFORMATION, ("Appointment within 15 minutes." + " " +
                                "Appointment ID: " + apptId + " on " + a.getAppointmentStartDate() + " at "
                                + a.getAppointmentStartTime()));
                        Optional<ButtonType> result = alert.showAndWait();
                    }
                }
            }

            if(!found){
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "No appointments within 15 minutes.");
                Optional<ButtonType> result = alert.showAndWait();

                loginUserIdTxt.getText();
            }

            successfulLogin = true;

            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/model/view/MainMenu.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }

        else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, bundle.getString("invalid"));
            alert.setHeaderText(bundle.getString("error"));
            alert.setTitle(bundle.getString("error"));
            Optional<ButtonType> result = alert.showAndWait();
            successfulLogin = false;
        }

        String successStatus = null;

        Timestamp loginTime = new Timestamp(System.currentTimeMillis());

        String filename = "login_activity.txt";

        PrintWriter outputFile = new PrintWriter(new FileOutputStream(filename, true),true);

        if(!successfulLogin){
            if(username.isEmpty()){
                username = "unidentified user";
            }
            successStatus = " HAD AN UNSUCCESSFUL LOGIN ATTEMPT AT ";
        }

        else{
            successStatus = " HAD A SUCCESSFUL LOGIN ATTEMPT AT ";
        }

        String outputString = "USER " + username + successStatus + loginTime + ".";

        outputFile.println(outputString);

        outputFile.flush();
        outputFile.close();
        System.out.println(outputString);

    }

    //LAMBDA
    @FXML
    private void onActionCancel(ActionEvent event){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(bundle.getString("confirmClose"));
        alert.showAndWait()
                .filter(response -> response == ButtonType.OK)
                .ifPresent((ButtonType response) -> {
                        DBConnection.closeConnection();
                        Platform.exit();
                        System.exit(0);
                });
    }
}
