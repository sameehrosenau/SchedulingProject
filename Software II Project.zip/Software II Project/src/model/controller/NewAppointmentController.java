package model.controller;

import dbAccess.*;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.Time;
import java.time.*;
import java.time.format.DateTimeParseException;
import java.util.ResourceBundle;

/**
 * the New Appointment Controller provides functionality for the user to add new appointments to the database.
 */

public class NewAppointmentController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private TextField newApptIdTxt;

    @FXML
    private TextField newApptTitleTxt;

    @FXML
    private TextArea newApptDescriptionTxt;

    @FXML
    private TextField newApptLocationTxt;

    @FXML
    private ComboBox <Contacts> newApptContactComboBx;

    @FXML
    private ComboBox <String> newApptTypeComboBx;

    @FXML
    private DatePicker newApptStartDatePicker;

    @FXML
    private TextField newApptStartTimeTxt;

    @FXML
    private DatePicker newApptEndDatePicker;

    @FXML
    private TextField newApptEndTimeTxt;

    @FXML
    private ComboBox <Customers> newApptCustomerIdComboBx;

    @FXML
    private ComboBox <Users> newApptUserIdComboBx;

    /**
     * The Initialize method of the New Appointment Controller sets the combo box values.
     * @param url
     * @param rb
     */

    public void initialize(URL url, ResourceBundle rb) {

        ObservableList<Contacts> contacts = DBContacts.getAllContacts();
        ObservableList<String> typesList = DBAppointments.getAllTypes();
        ObservableList<Customers> custIdsList = DBCustomers.getAllCustomers();
        ObservableList<Users> userIdsList = DBUsers.getAllUsers();
        newApptContactComboBx.setItems(contacts);
        newApptTypeComboBx.setItems(typesList);
        newApptCustomerIdComboBx.setItems(custIdsList);
        newApptUserIdComboBx.setItems(userIdsList);

    }

    /**
     * the Save event handler captures all of the information entered into the new customer fields and saves it to the
     * database if all of the fields contain valid input.
     *
     * The user is then returned to the scheduling menu.
     * @param event
     * @throws IOException
     */
    @FXML
    private void onActionSaveApptReturnSchedulingMenu(ActionEvent event) throws IOException {
        String appointmentTitle = newApptTitleTxt.getText();
        String appointmentDescription = newApptDescriptionTxt.getText();
        String appointmentLocation = newApptLocationTxt.getText();
        String appointmentType = String.valueOf(newApptTypeComboBx.getValue());
        LocalDate appointmentStartDate = newApptStartDatePicker.getValue();
        LocalTime appointmentStartTime = LocalTime.parse(newApptStartTimeTxt.getText());
        LocalDate appointmentEndDate = newApptEndDatePicker.getValue();
        LocalTime appointmentEndTime = LocalTime.parse(newApptEndTimeTxt.getText());

        Customers C = newApptCustomerIdComboBx.getValue();
        if (C == null) {
            return;
        }
        Users U = newApptUserIdComboBx.getValue();
        if (U == null) {
            return;
        }
        Contacts X = (newApptContactComboBx.getValue());
        if (X == null) {
            return;
        }

        int customerId = C.getCustomerId();
        int userId = U.getUserId();
        int contactId = X.getContactId();

        if(appointmentType == null){
            return;
        }

        LocalTime estStart = LocalTime.of(8,0);
        LocalTime estEnd = LocalTime.of(22, 0);
        LocalDateTime localStart = LocalDateTime.of(appointmentStartDate, appointmentStartTime);
        ZonedDateTime localZonedStart = localStart.atZone(ZoneId.systemDefault());
        ZonedDateTime estZonedStart = localZonedStart.withZoneSameInstant(ZoneId.of("America/New_York"));
        LocalTime estStartTest = estZonedStart.toLocalTime();
        if(estStart.isAfter(estStartTest)){
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Error");
            alert1.setContentText("The appointment start time is outside of business hours.");
            alert1.showAndWait();
            return;
        }

        LocalDateTime localEnd = LocalDateTime.of(appointmentEndDate, appointmentEndTime);
        ZonedDateTime localZonedEnd = localEnd.atZone(ZoneId.systemDefault());
        ZonedDateTime estZonedEnd = localZonedEnd.withZoneSameInstant(ZoneId.of("America/New_York"));
        LocalTime estEndTest = estZonedEnd.toLocalTime();
        if(estEnd.isBefore(estEndTest)){
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Error");
            alert1.setContentText("The appointment end time is outside of business hours.");
            alert1.showAndWait();
            return;
        }

        //make sure start time is before end time
        if(localStart.isAfter(localEnd)){
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Error");
            alert1.setContentText("The appointment start time must be before the appointment end time.");
            alert1.showAndWait();
            return;
        }

        ObservableList <Appointments> aList = DBAppointments.getAllAppointments();

        for(Appointments a : aList){
            if(a.getCustomerId() != customerId){
                continue;
            }
            if(!a.getAppointmentStartDate().equals(appointmentStartDate)){
                continue;
            }

            //exS = existing StartTime
            //exE = existing EndTime
            //
            //newS = new StartTime
            //newE = new EndTime
            LocalTime exS = appointmentStartTime;
            LocalTime exE = appointmentEndTime;

            LocalTime newS = a.getAppointmentStartTime();
            LocalTime newE = a.getAppointmentEndTime();

            if(((newS.isBefore(exS) || newS.equals(exS)) && (newE.isBefore(exE) || newE.equals(exE)))){
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Error");
                alert1.setContentText("Appointment ID: " + a.getAppointmentId() + " overlaps with the appointment" +
                        " the user is attempting to create.");
                alert1.showAndWait();
                return;
            }
            if((newS.isAfter(exS) || newS.equals(exS)) && (newE.isAfter(exE))){
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Error");
                alert1.setContentText("Appointment ID: " + a.getAppointmentId() + " overlaps with the appointment" +
                        " the user is attempting to create.");
                alert1.showAndWait();
                return;
            }
            if((newS.isAfter(exS) || newS.equals(exS)) && (newE.isBefore(exE) || newE.equals(exE))){
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Error");
                alert1.setContentText("Appointment ID: " + a.getAppointmentId() + " overlaps with the appointment" +
                        " the user is attempting to create.");
                alert1.showAndWait();
                return;
            }
            if(newS.isAfter(exS) && newE.isBefore(exE)){
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Error");
                alert1.setContentText("Appointment ID: " + a.getAppointmentId() + " overlaps with the appointment" +
                        " the user is attempting to create.");
                alert1.showAndWait();
                return;
            }

        }

        DBAppointments.createAppointment(appointmentTitle, appointmentDescription,
                appointmentLocation, appointmentType, appointmentStartDate, appointmentStartTime, appointmentEndDate,
                appointmentEndTime, customerId, userId, contactId);


        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/SchedulingMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * the cancel handler returns the user to the scheduling menu without saving any entered data.
     * @param event
     * @throws IOException
     */

    @FXML
    private void onActionReturnToSchedulingMenu(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/model/view/SchedulingMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @Override
    public String toString(){
        return newApptStartTimeTxt.toString();
    }

}
