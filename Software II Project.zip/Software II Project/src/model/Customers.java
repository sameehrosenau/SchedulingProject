package model;

public class Customers {
    private int customerId;
    private String customerName;
    private String customerAddress;
    private String customerPostCode;
    private String customerPhone;
    private int customerDivisionId;
    private int countryId;
    private String countryName;
    private String divisionName;

    private static int custCount = 0;

    public Customers(int customerId, String customerName, String customerAddress, String customerPostCode,
                     String customerPhone, int countryId, String countryName, int customerDivisionId, String divisionName) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerPostCode = customerPostCode;
        this.customerPhone = customerPhone;
        this.countryName = countryName;
        this.divisionName = divisionName;
        this.countryId = countryId;
        this.customerDivisionId = customerDivisionId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public String getCustomerPostCode() {
        return customerPostCode;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public int getCustomerDivisionId() {
        return customerDivisionId;
    }

    public int getCountryId() {
        return countryId;
    }

    public String getCountryName() {
        return countryName;
    }

    public String getDivisionName() {
        return divisionName;
    }

    @Override
    public String toString(){
        return customerName;
    }


}
