package model;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import database.DBConnection;

import java.io.*;
import java.util.Locale;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("/model/view/LogInScreen.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) throws IOException{
        //Locale.setDefault(new Locale("fr"));

        //attain DB connection
        DBConnection.startConnection();
        launch(args);
        DBConnection.closeConnection();
    }
}
