package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * this class establishes the database connection method.
 */
public class DBConnection {

    /**
     *     JDBC URL elements created
      */
    private static final String protocol = "jdbc";
    private static final String vendorName = ":mysql:";
    private static final String ipAddress = "//wgudb.ucertify.com:3306/";
    private static final String dbName = "WJ07bOD";

    /**
     *    JDBC URL elements concatenated
      */
    private static final String jdbcURL = protocol + vendorName + ipAddress + dbName;

    private static final String mysqlJDBCdriver = "com.mysql.jdbc.Driver";

    //username
    private static final String username = "U07bOD";

    //password
    private static final String password = "53688981904";
    private static Connection conn = null;

    /**
     * the startConnection function starts up the database connection
     * @return
     */
    public static Connection startConnection() {
        try {
            Class.forName(mysqlJDBCdriver);
            conn = DriverManager.getConnection(jdbcURL, username, password);

            System.out.println("Connection successful.");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return conn;
    }

    /**
     * the getConnection function retrieves the connection to the database at will.
     * less cpu-intensive than calling startConnection every time you need a DB connection
     * @return
     */
    public static Connection getConnection() {
        return conn;
    }

    /**
     * the closeConnection function ends the connection to the database
     */
    public static void closeConnection(){
        try{
            conn.close();
        }
        catch (Exception e){
        }
    }
}