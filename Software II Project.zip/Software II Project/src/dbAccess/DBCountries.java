package dbAccess;

import com.mysql.cj.x.protobuf.MysqlxPrepare;
import database.DBConnection;
import model.Countries;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class DBCountries {

    /**
     * the getAllCountries function returns a list of all countries in the database, "countriesList".
     * @return
     */
    public static ObservableList<Countries> getAllCountries() {

        ObservableList<Countries> countriesList = FXCollections.observableArrayList();

        try{
            String sql = "SELECT * from countries";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int countryId = rs.getInt("Country_ID");
                String countryName = rs.getString("Country");
                Countries C = new Countries(countryId, countryName);
                countriesList.add(C);
            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return countriesList;
    }

    /**
     * the checkDateConversion function checks that dates are properly converted between database time and user time.
     */
    public static void checkDateConversion() {

        System.out.println("Create Date Test");
        String sql = "select Create_Date from countries";
        try {
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Timestamp ts = rs.getTimestamp("Create_Data");
                System.out.println("CD: " + ts.toLocalDateTime().toString());
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

}
