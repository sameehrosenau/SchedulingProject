package dbAccess;

import database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Users;

import java.sql.*;

public class DBUsers {

    /**
     * the getAllUserIds function returns a list of userIds
     * @return
     */
    public static ObservableList<Integer> getAllUserIds(){
        ObservableList<Integer> userIdsList = FXCollections.observableArrayList();

        try{
            String sql = "SELECT * from users";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int userId = rs.getInt("User_ID");

                userIdsList.add(userId);
            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return userIdsList;
    }

    /**
     * the getAllUsers function returns a list of all users in the database
     * @return
     */
    public static ObservableList<Users> getAllUsers() {

        ObservableList<Users> usersList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * from users";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int userId = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");
                String password = rs.getString("Password");
                Timestamp userCreated = rs.getTimestamp("Create_Date");
                String userCreatedBy = rs.getString("Created_By");
                Timestamp userLastUpdated = rs.getTimestamp("Last_Update");
                String userLastUpdatedBy = rs.getString("Last_Updated_By");

                Users U = new Users(userId, userName, password, userCreated, userCreatedBy,
                        userLastUpdated, userLastUpdatedBy);
                usersList.add(U);
            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return usersList;
    }

    public static Users getUser(String username, String password) {

        ObservableList<Users> usersList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * from users WHERE User_Name = ? AND Password = ?";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");
                String pass_word = rs.getString("Password");
                Timestamp userCreated = rs.getTimestamp("Create_Date");
                String userCreatedBy = rs.getString("Created_By");
                Timestamp userLastUpdated = rs.getTimestamp("Last_Update");
                String userLastUpdatedBy = rs.getString("Last_Updated_By");

                Users U = new Users(userId, userName, pass_word, userCreated, userCreatedBy,
                        userLastUpdated, userLastUpdatedBy);
                return U;
            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return null;
    }
}