package dbAccess;

import database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointments;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class DBAppointments {

    /**
     * the getMonths function returns a list of months.
     * @return
     */
    public static ObservableList<String> getMonths(){
        ObservableList<String> monthsList = FXCollections.observableArrayList();
        monthsList.add("January");
        monthsList.add("February");
        monthsList.add("March");
        monthsList.add("April");
        monthsList.add("May");
        monthsList.add("June");
        monthsList.add("July");
        monthsList.add("August");
        monthsList.add("September");
        monthsList.add("October");
        monthsList.add("November");
        monthsList.add("December");

        return monthsList;
    }

    /**
     * the getAllTypes function returns a list of appointment types.
     *
     */
    public static ObservableList<String> getAllTypes(){

        ObservableList<String> typesList = FXCollections.observableArrayList();
        typesList.add("Prospective Client Lunch");
        typesList.add("Product Demo");
        typesList.add("Conference");

        return typesList;
    }

    /**
     * the getAllAppointments function returns a list of all appointments.
     * @return
     */
    public static ObservableList<Appointments> getAllAppointments() {

        ObservableList<Appointments> appointmentsList = FXCollections.observableArrayList();

        try{
            String sql = "SELECT * FROM appointments";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int appointmentId = rs.getInt("Appointment_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDescription = rs.getString("Description");
                String appointmentLocation = rs.getString("Location");
                String appointmentType = rs.getString("Type");
                LocalDate appointmentStartDate = rs.getTimestamp("Start").toLocalDateTime().toLocalDate();
                LocalTime appointmentStartTime = rs.getTimestamp("Start").toLocalDateTime().toLocalTime();
                LocalDate appointmentEndDate = rs.getTimestamp("End").toLocalDateTime().toLocalDate();
                LocalTime appointmentEndTime = rs.getTimestamp("End").toLocalDateTime().toLocalTime();
                int customerId = rs.getInt("Customer_ID");
                int userId = rs.getInt("User_ID");
                int contactId = rs.getInt("Contact_ID");

                Appointments A = new Appointments(appointmentId, appointmentTitle, appointmentDescription,
                        appointmentLocation, appointmentType, appointmentStartDate, appointmentStartTime,
                        appointmentEndDate, appointmentEndTime, customerId, userId, contactId);
                appointmentsList.add(A);
            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return appointmentsList;
    }

    public static ObservableList<Appointments> getMonthlyAppointments() {

        ObservableList<Appointments> monthlyAppointments = FXCollections.observableArrayList();

        try{
            String sql = "SELECT * FROM appointments WHERE MONTH(Start) = MONTH(NOW())";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int appointmentId = rs.getInt("Appointment_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDescription = rs.getString("Description");
                String appointmentLocation = rs.getString("Location");
                String appointmentType = rs.getString("Type");
                LocalDate appointmentStartDate = rs.getTimestamp("Start").toLocalDateTime().toLocalDate();
                LocalTime appointmentStartTime = rs.getTimestamp("Start").toLocalDateTime().toLocalTime();
                LocalDate appointmentEndDate = rs.getTimestamp("End").toLocalDateTime().toLocalDate();
                LocalTime appointmentEndTime = rs.getTimestamp("End").toLocalDateTime().toLocalTime();
                int customerId = rs.getInt("Customer_ID");
                int userId = rs.getInt("User_ID");
                int contactId = rs.getInt("Contact_ID");

                Appointments A = new Appointments(appointmentId, appointmentTitle, appointmentDescription,
                        appointmentLocation, appointmentType, appointmentStartDate, appointmentStartTime,
                        appointmentEndDate, appointmentEndTime, customerId, userId, contactId);
                monthlyAppointments.add(A);
            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return monthlyAppointments;
    }

    /**
     * the deleteAppointment function deletes the selected appointment
     * @param selectedAppointment
     */
    public static void deleteAppointment(Appointments selectedAppointment) {

        try {
            String sqlDelAppt = "DELETE from appointments WHERE Appointment_ID = ?";

            PreparedStatement pstA = DBConnection.getConnection().prepareStatement(sqlDelAppt);

            pstA.setInt(1, selectedAppointment.getAppointmentId());

            pstA.execute();
        }

        catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * the createAppointment function creates a new appointment in the database
     * @param appointmentTitle
     * @param appointmentDescription
     * @param appointmentLocation
     * @param appointmentType
     * @param appointmentStartDate
     * @param appointmentStartTime
     * @param appointmentEndDate
     * @param appointmentEndTime
     * @param customerId
     * @param userId
     * @param contactId
     */
    public static void createAppointment(String appointmentTitle, String appointmentDescription,
                                         String appointmentLocation, String appointmentType, LocalDate appointmentStartDate,
                                         LocalTime appointmentStartTime, LocalDate appointmentEndDate, LocalTime appointmentEndTime,
                                         int customerId, int userId, int contactId) {
        try {
            LocalDateTime Start = LocalDateTime.of(appointmentStartDate, appointmentStartTime);
            LocalDateTime End = LocalDateTime.of(appointmentEndDate, appointmentEndTime);

            String sqlAddAppt = "INSERT INTO appointments VALUES(NULL, ?, ?, ?, ?, ?, ?, NOW(), '', NOW(), '', ?, ?, ?)";

            PreparedStatement pst = DBConnection.getConnection().prepareStatement(sqlAddAppt);

            pst.setString(1, appointmentTitle);
            pst.setString(2, appointmentDescription);
            pst.setString(3, appointmentLocation);
            pst.setString(4, appointmentType);
            pst.setTimestamp(5, Timestamp.valueOf(Start));
            pst.setTimestamp(6, Timestamp.valueOf(End));
            pst.setInt(7, customerId);
            pst.setInt(8, userId);
            pst.setInt(9, contactId);

            pst.execute();

        }
        catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * the editAppointment function allows the user to edit details of an existing appointment.
     * @param appointmentId
     * @param appointmentTitle
     * @param appointmentDescription
     * @param appointmentLocation
     * @param appointmentType
     * @param appointmentStartDate
     * @param appointmentStartTime
     * @param appointmentEndDate
     * @param appointmentEndTime
     * @param customerId
     * @param userId
     * @param contactId
     */
    public static void editAppointment(int appointmentId, String appointmentTitle, String appointmentDescription,
                                       String appointmentLocation, String appointmentType, LocalDate appointmentStartDate,
                                       LocalTime appointmentStartTime, LocalDate appointmentEndDate,
                                       LocalTime appointmentEndTime, int customerId, int userId, int contactId) {

        try {
            LocalDateTime Start = LocalDateTime.of(appointmentStartDate, appointmentStartTime);
            LocalDateTime End = LocalDateTime.of(appointmentEndDate, appointmentEndTime);

            String sqlAddCust = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Contact_ID = ?, " +
                    "Type = ?, Start = ?, End = ?, Customer_ID = ?, User_ID = ? WHERE Appointment_ID = ?";

            PreparedStatement pst = DBConnection.getConnection().prepareStatement(sqlAddCust);

            pst.setString(1, appointmentTitle);
            pst.setString(2, appointmentDescription);
            pst.setString(3, appointmentLocation);
            pst.setInt(4, contactId);
            pst.setString(5, appointmentType);
            pst.setTimestamp(6, Timestamp.valueOf(Start));
            pst.setTimestamp(7, Timestamp.valueOf(End));
            pst.setInt(8, customerId);
            pst.setInt(9, userId);
            pst.setInt(10, appointmentId);

            pst.execute();

        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static ObservableList<Appointments> getWeeklyAppointments() {
        ObservableList<Appointments> weeklyAppointments = FXCollections.observableArrayList();

        try{
            String sql = "SELECT * FROM appointments WHERE WEEK(Start) = Week(NOW())";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int appointmentId = rs.getInt("Appointment_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDescription = rs.getString("Description");
                String appointmentLocation = rs.getString("Location");
                String appointmentType = rs.getString("Type");
                LocalDate appointmentStartDate = rs.getTimestamp("Start").toLocalDateTime().toLocalDate();
                LocalTime appointmentStartTime = rs.getTimestamp("Start").toLocalDateTime().toLocalTime();
                LocalDate appointmentEndDate = rs.getTimestamp("End").toLocalDateTime().toLocalDate();
                LocalTime appointmentEndTime = rs.getTimestamp("End").toLocalDateTime().toLocalTime();
                int customerId = rs.getInt("Customer_ID");
                int userId = rs.getInt("User_ID");
                int contactId = rs.getInt("Contact_ID");

                Appointments A = new Appointments(appointmentId, appointmentTitle, appointmentDescription,
                        appointmentLocation, appointmentType, appointmentStartDate, appointmentStartTime,
                        appointmentEndDate, appointmentEndTime, customerId, userId, contactId);
                weeklyAppointments.add(A);
            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return weeklyAppointments;
    }
}
