package dbAccess;

import database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Divisions;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class DBDivisions {

    /**
     * the getAllDivisions function returns a list of all divisions in the database, "divisionsList".
     * @return
     */
    public static ObservableList<Divisions> getAllDivisions() {

        ObservableList<Divisions> divisionsList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * from first_level_divisions";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int divisionId = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                Timestamp divisionCreated = rs.getTimestamp("Create_Date");
                String divisionCreatedBy = rs.getString("Created_By");
                Timestamp divisionLastUpdate = rs.getTimestamp("Last_Update");
                String divisionLastUpdatedBy = rs.getString("Last_Updated_By");
                int countryId = rs.getInt("COUNTRY_ID");
                Divisions D = new Divisions(divisionId, divisionName, divisionCreated, divisionCreatedBy,
                        divisionLastUpdate, divisionLastUpdatedBy, countryId);
                divisionsList.add(D);
            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return divisionsList;
    }

    /**
     * the getAllDivisionsByCountry function returns a list of all divisions subdivided by country.
     * ex. Wales in the UK, Alabama in the US, Quebec in Canada.
     * @return
     */
    public static ObservableList<Divisions> getAllDivisionsByCountry(int cId) {
        ObservableList<Divisions> divisionsList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * from first_level_divisions WHERE country_id = ?";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setInt(1, cId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int divisionId = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                Timestamp divisionCreated = rs.getTimestamp("Create_Date");
                String divisionCreatedBy = rs.getString("Created_By");
                Timestamp divisionLastUpdate = rs.getTimestamp("Last_Update");
                String divisionLastUpdatedBy = rs.getString("Last_Updated_By");
                int countryId = rs.getInt("COUNTRY_ID");
                Divisions D = new Divisions(divisionId, divisionName, divisionCreated, divisionCreatedBy,
                        divisionLastUpdate, divisionLastUpdatedBy, countryId);
                divisionsList.add(D);
            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return divisionsList;
    }
}