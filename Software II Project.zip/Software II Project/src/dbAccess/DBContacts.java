package dbAccess;

import database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Contacts;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBContacts {

    /**
     * the getAllContacts function returns a list of all contacts in the database, "contactsList".
     * @return
     */
    public static ObservableList<Contacts> getAllContacts() {

        ObservableList<Contacts> contactsList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * from contacts";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int contactId = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");
                String contactEmail = rs.getString("Email");
                Contacts C = new Contacts(contactId, contactName, contactEmail);
                contactsList.add(C);
            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return contactsList;
    }
}