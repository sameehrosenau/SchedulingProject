package dbAccess;

import database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBCustomers {

    /**
     * the getAllCustomerIds function returns a list of customer Ids
     * @return
     */
    public static ObservableList<Integer> getAllCustomerIds(){
        ObservableList<Integer> custIdsList = FXCollections.observableArrayList();

        try{
            String sql = "SELECT * from customers";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int customerId = rs.getInt("Customer_ID");

                custIdsList.add(customerId);

            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return custIdsList;
    }

    /**
     * the getAllCustomers function returns a list of all customers in the DB
     * @return
     */

    public static ObservableList<Customers> getAllCustomers() {

        ObservableList<Customers> customersList = FXCollections.observableArrayList();

        try{
            String sql = "SELECT Customer_ID, Customer_Name, Address, Postal_Code, Phone, c.Division_ID, fld.Division, " +
                    "fld.COUNTRY_ID, cn.Country FROM customers c, first_level_divisions fld, countries cn " +
                    "WHERE c.Division_ID = fld.Division_ID AND cn.Country_ID = fld.COUNTRY_ID";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int customerId = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String customerAddress = rs.getString("Address");
                String customerPostCode = rs.getString("Postal_Code");
                String customerPhone = rs.getString("Phone");
                int customerDivisionId = rs.getInt("Division_ID");
                int countryId = rs.getInt("COUNTRY_ID");
                String countryName = rs.getString("country");
                String divisionName = rs.getString("Division");

                Customers C = new Customers(customerId, customerName, customerAddress, customerPostCode,
                        customerPhone, countryId, countryName, customerDivisionId, divisionName);
                customersList.add(C);

            }
        }

        catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return customersList;
    }

    /**
     * the createCustomer function adds the values entered into the newCustomer view fields into the database
     * under one unique customer id, generated automatically by the DB.
     */
    public static void createCustomer(String customerName, String customerAddress,
                                      String customerPostCode, String customerPhone, int divisionId) {
        try {
            String sqlAddCust = "INSERT INTO customers VALUES(NULL, ?, ?, ?, ?, NOW(), '', NOW(), '', ?)";

            PreparedStatement pst = DBConnection.getConnection().prepareStatement(sqlAddCust);

            pst.setString(1, customerName);
            pst.setString(2, customerAddress);
            pst.setString(3, customerPostCode);
            pst.setString(4, customerPhone);
            pst.setInt(5, divisionId);

            pst.execute();

        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * the delete customer function removes the selected customer data from the database
     * IF there are no associated appointments
     * @param selectedCustomer
     */
    public static void deleteCustomer(Customers selectedCustomer) {
        try {
            String sqlDelAppt = "DELETE from appointments WHERE Customer_ID = ?";

            PreparedStatement pst = DBConnection.getConnection().prepareStatement(sqlDelAppt);

            pst.setInt(1, selectedCustomer.getCustomerId());

            pst.execute();

            String sqlDelCust = "DELETE from customers WHERE Customer_ID = ?";

            PreparedStatement pstc = DBConnection.getConnection().prepareStatement(sqlDelCust);

            pstc.setInt(1, selectedCustomer.getCustomerId());

            pstc.execute();

        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * the EditCustomer function commits the changes to a customer record to the database.
     * @param customerName
     * @param customerAddress
     * @param customerPostCode
     * @param customerPhone
     * @param divisionId
     * @param customerId
     */
    public static void editCustomer(String customerName, String customerAddress, String customerPostCode,
                                    String customerPhone, int divisionId, int customerId) {
        try {
            String sqlAddCust = "UPDATE customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, " +
                    "Division_ID = ? WHERE Customer_ID = ?";

            PreparedStatement pst = DBConnection.getConnection().prepareStatement(sqlAddCust);

            pst.setString(1, customerName);
            pst.setString(2, customerAddress);
            pst.setString(3, customerPostCode);
            pst.setString(4, customerPhone);
            pst.setInt(5, divisionId);
            pst.setInt(6, customerId);

            pst.execute();

        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}