Title: Inventory Project
Purpose: Allow users to create/edit/delete customer records as well as create/edit/delete/track appointments with
customers.
Author: Samantha Rosenau
Email: srosena@wgu.edu
App Version: QAM1
IDE: IntelliJ Community 2020.3.2
JDK: 11.0.10
JavaFX 11.0.2

To run the program, go to the src folder. From src, go to model. In model, select Main.java and run it in your IDE.

For the third report, I provided users with the ability to retrieve the total number of customers in a given country. I
imagine this would be an interesting metric for tracking how the business is doing with client acquisition across
markets.

MySQL Driver Version Number: 8.0.22